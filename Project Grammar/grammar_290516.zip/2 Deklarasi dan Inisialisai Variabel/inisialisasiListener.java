// Generated from inisialisasi.g4 by ANTLR 4.5.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link inisialisasiParser}.
 */
public interface inisialisasiListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(inisialisasiParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(inisialisasiParser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterStatement(inisialisasiParser.StatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitStatement(inisialisasiParser.StatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#pointer}.
	 * @param ctx the parse tree
	 */
	void enterPointer(inisialisasiParser.PointerContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#pointer}.
	 * @param ctx the parse tree
	 */
	void exitPointer(inisialisasiParser.PointerContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#array}.
	 * @param ctx the parse tree
	 */
	void enterArray(inisialisasiParser.ArrayContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#array}.
	 * @param ctx the parse tree
	 */
	void exitArray(inisialisasiParser.ArrayContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#struct}.
	 * @param ctx the parse tree
	 */
	void enterStruct(inisialisasiParser.StructContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#struct}.
	 * @param ctx the parse tree
	 */
	void exitStruct(inisialisasiParser.StructContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#dec}.
	 * @param ctx the parse tree
	 */
	void enterDec(inisialisasiParser.DecContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#dec}.
	 * @param ctx the parse tree
	 */
	void exitDec(inisialisasiParser.DecContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#type_int}.
	 * @param ctx the parse tree
	 */
	void enterType_int(inisialisasiParser.Type_intContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#type_int}.
	 * @param ctx the parse tree
	 */
	void exitType_int(inisialisasiParser.Type_intContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#init_struct}.
	 * @param ctx the parse tree
	 */
	void enterInit_struct(inisialisasiParser.Init_structContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#init_struct}.
	 * @param ctx the parse tree
	 */
	void exitInit_struct(inisialisasiParser.Init_structContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#size}.
	 * @param ctx the parse tree
	 */
	void enterSize(inisialisasiParser.SizeContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#size}.
	 * @param ctx the parse tree
	 */
	void exitSize(inisialisasiParser.SizeContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#init_array1}.
	 * @param ctx the parse tree
	 */
	void enterInit_array1(inisialisasiParser.Init_array1Context ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#init_array1}.
	 * @param ctx the parse tree
	 */
	void exitInit_array1(inisialisasiParser.Init_array1Context ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#init_array2}.
	 * @param ctx the parse tree
	 */
	void enterInit_array2(inisialisasiParser.Init_array2Context ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#init_array2}.
	 * @param ctx the parse tree
	 */
	void exitInit_array2(inisialisasiParser.Init_array2Context ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#init_array3}.
	 * @param ctx the parse tree
	 */
	void enterInit_array3(inisialisasiParser.Init_array3Context ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#init_array3}.
	 * @param ctx the parse tree
	 */
	void exitInit_array3(inisialisasiParser.Init_array3Context ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#init_array4}.
	 * @param ctx the parse tree
	 */
	void enterInit_array4(inisialisasiParser.Init_array4Context ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#init_array4}.
	 * @param ctx the parse tree
	 */
	void exitInit_array4(inisialisasiParser.Init_array4Context ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#value1}.
	 * @param ctx the parse tree
	 */
	void enterValue1(inisialisasiParser.Value1Context ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#value1}.
	 * @param ctx the parse tree
	 */
	void exitValue1(inisialisasiParser.Value1Context ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#value2}.
	 * @param ctx the parse tree
	 */
	void enterValue2(inisialisasiParser.Value2Context ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#value2}.
	 * @param ctx the parse tree
	 */
	void exitValue2(inisialisasiParser.Value2Context ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#value3}.
	 * @param ctx the parse tree
	 */
	void enterValue3(inisialisasiParser.Value3Context ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#value3}.
	 * @param ctx the parse tree
	 */
	void exitValue3(inisialisasiParser.Value3Context ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#value4}.
	 * @param ctx the parse tree
	 */
	void enterValue4(inisialisasiParser.Value4Context ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#value4}.
	 * @param ctx the parse tree
	 */
	void exitValue4(inisialisasiParser.Value4Context ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#type_CHAR}.
	 * @param ctx the parse tree
	 */
	void enterType_CHAR(inisialisasiParser.Type_CHARContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#type_CHAR}.
	 * @param ctx the parse tree
	 */
	void exitType_CHAR(inisialisasiParser.Type_CHARContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#type_FLOAT}.
	 * @param ctx the parse tree
	 */
	void enterType_FLOAT(inisialisasiParser.Type_FLOATContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#type_FLOAT}.
	 * @param ctx the parse tree
	 */
	void exitType_FLOAT(inisialisasiParser.Type_FLOATContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#type_DOUBLE}.
	 * @param ctx the parse tree
	 */
	void enterType_DOUBLE(inisialisasiParser.Type_DOUBLEContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#type_DOUBLE}.
	 * @param ctx the parse tree
	 */
	void exitType_DOUBLE(inisialisasiParser.Type_DOUBLEContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#type_INT}.
	 * @param ctx the parse tree
	 */
	void enterType_INT(inisialisasiParser.Type_INTContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#type_INT}.
	 * @param ctx the parse tree
	 */
	void exitType_INT(inisialisasiParser.Type_INTContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#init_pointer1}.
	 * @param ctx the parse tree
	 */
	void enterInit_pointer1(inisialisasiParser.Init_pointer1Context ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#init_pointer1}.
	 * @param ctx the parse tree
	 */
	void exitInit_pointer1(inisialisasiParser.Init_pointer1Context ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#init_pointer2}.
	 * @param ctx the parse tree
	 */
	void enterInit_pointer2(inisialisasiParser.Init_pointer2Context ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#init_pointer2}.
	 * @param ctx the parse tree
	 */
	void exitInit_pointer2(inisialisasiParser.Init_pointer2Context ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#deklarasi}.
	 * @param ctx the parse tree
	 */
	void enterDeklarasi(inisialisasiParser.DeklarasiContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#deklarasi}.
	 * @param ctx the parse tree
	 */
	void exitDeklarasi(inisialisasiParser.DeklarasiContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#typedata}.
	 * @param ctx the parse tree
	 */
	void enterTypedata(inisialisasiParser.TypedataContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#typedata}.
	 * @param ctx the parse tree
	 */
	void exitTypedata(inisialisasiParser.TypedataContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#type_data}.
	 * @param ctx the parse tree
	 */
	void enterType_data(inisialisasiParser.Type_dataContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#type_data}.
	 * @param ctx the parse tree
	 */
	void exitType_data(inisialisasiParser.Type_dataContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#integer_s}.
	 * @param ctx the parse tree
	 */
	void enterInteger_s(inisialisasiParser.Integer_sContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#integer_s}.
	 * @param ctx the parse tree
	 */
	void exitInteger_s(inisialisasiParser.Integer_sContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#integer_v}.
	 * @param ctx the parse tree
	 */
	void enterInteger_v(inisialisasiParser.Integer_vContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#integer_v}.
	 * @param ctx the parse tree
	 */
	void exitInteger_v(inisialisasiParser.Integer_vContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#char_s}.
	 * @param ctx the parse tree
	 */
	void enterChar_s(inisialisasiParser.Char_sContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#char_s}.
	 * @param ctx the parse tree
	 */
	void exitChar_s(inisialisasiParser.Char_sContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#char_v}.
	 * @param ctx the parse tree
	 */
	void enterChar_v(inisialisasiParser.Char_vContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#char_v}.
	 * @param ctx the parse tree
	 */
	void exitChar_v(inisialisasiParser.Char_vContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#float_s}.
	 * @param ctx the parse tree
	 */
	void enterFloat_s(inisialisasiParser.Float_sContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#float_s}.
	 * @param ctx the parse tree
	 */
	void exitFloat_s(inisialisasiParser.Float_sContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#float_v}.
	 * @param ctx the parse tree
	 */
	void enterFloat_v(inisialisasiParser.Float_vContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#float_v}.
	 * @param ctx the parse tree
	 */
	void exitFloat_v(inisialisasiParser.Float_vContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#double_s}.
	 * @param ctx the parse tree
	 */
	void enterDouble_s(inisialisasiParser.Double_sContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#double_s}.
	 * @param ctx the parse tree
	 */
	void exitDouble_s(inisialisasiParser.Double_sContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#double_v}.
	 * @param ctx the parse tree
	 */
	void enterDouble_v(inisialisasiParser.Double_vContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#double_v}.
	 * @param ctx the parse tree
	 */
	void exitDouble_v(inisialisasiParser.Double_vContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#boolean_s}.
	 * @param ctx the parse tree
	 */
	void enterBoolean_s(inisialisasiParser.Boolean_sContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#boolean_s}.
	 * @param ctx the parse tree
	 */
	void exitBoolean_s(inisialisasiParser.Boolean_sContext ctx);
	/**
	 * Enter a parse tree produced by {@link inisialisasiParser#boolean_v}.
	 * @param ctx the parse tree
	 */
	void enterBoolean_v(inisialisasiParser.Boolean_vContext ctx);
	/**
	 * Exit a parse tree produced by {@link inisialisasiParser#boolean_v}.
	 * @param ctx the parse tree
	 */
	void exitBoolean_v(inisialisasiParser.Boolean_vContext ctx);
}