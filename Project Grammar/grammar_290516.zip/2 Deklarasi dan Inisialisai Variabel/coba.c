struct identitas{
	float ngawur[20];
	int umur;
	char darah;
}
struct identitas data1, data2;
data1.umur=10;