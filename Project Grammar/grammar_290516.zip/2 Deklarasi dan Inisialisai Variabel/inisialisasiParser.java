// Generated from inisialisasi.g4 by ANTLR 4.5.2
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class inisialisasiParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.5.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, T__19=20, T__20=21, T__21=22, T__22=23, T__23=24, 
		T__24=25, T__25=26, Identifier=27, INT=28, CHAR=29, UNSG=30, FLOAT=31, 
		DOUBLE=32, Whitespace=33, Newline=34, BlockComment=35, LineComment=36;
	public static final int
		RULE_prog = 0, RULE_statement = 1, RULE_pointer = 2, RULE_array = 3, RULE_struct = 4, 
		RULE_dec = 5, RULE_type_int = 6, RULE_init_struct = 7, RULE_size = 8, 
		RULE_init_array1 = 9, RULE_init_array2 = 10, RULE_init_array3 = 11, RULE_init_array4 = 12, 
		RULE_value1 = 13, RULE_value2 = 14, RULE_value3 = 15, RULE_value4 = 16, 
		RULE_type_CHAR = 17, RULE_type_FLOAT = 18, RULE_type_DOUBLE = 19, RULE_type_INT = 20, 
		RULE_init_pointer1 = 21, RULE_init_pointer2 = 22, RULE_deklarasi = 23, 
		RULE_typedata = 24, RULE_type_data = 25, RULE_integer_s = 26, RULE_integer_v = 27, 
		RULE_char_s = 28, RULE_char_v = 29, RULE_float_s = 30, RULE_float_v = 31, 
		RULE_double_s = 32, RULE_double_v = 33, RULE_boolean_s = 34, RULE_boolean_v = 35;
	public static final String[] ruleNames = {
		"prog", "statement", "pointer", "array", "struct", "dec", "type_int", 
		"init_struct", "size", "init_array1", "init_array2", "init_array3", "init_array4", 
		"value1", "value2", "value3", "value4", "type_CHAR", "type_FLOAT", "type_DOUBLE", 
		"type_INT", "init_pointer1", "init_pointer2", "deklarasi", "typedata", 
		"type_data", "integer_s", "integer_v", "char_s", "char_v", "float_s", 
		"float_v", "double_s", "double_v", "boolean_s", "boolean_v"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "';'", "'const'", "'='", "'unsigned'", "'struct'", "'{'", "'}'", 
		"','", "'.'", "'short'", "'int'", "'long'", "'['", "']'", "'char'", "'float'", 
		"'double'", "'*'", "'&'", "'boolean'", "'\"'", "'''", "'TRUE'", "'FALSE'", 
		"'true'", "'false'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, null, null, null, null, null, null, null, null, null, null, null, 
		null, null, null, null, null, null, null, null, null, null, null, null, 
		null, null, null, "Identifier", "INT", "CHAR", "UNSG", "FLOAT", "DOUBLE", 
		"Whitespace", "Newline", "BlockComment", "LineComment"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "inisialisasi.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public inisialisasiParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ProgContext extends ParserRuleContext {
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public ProgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prog; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterProg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitProg(this);
		}
	}

	public final ProgContext prog() throws RecognitionException {
		ProgContext _localctx = new ProgContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_prog);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(73); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(72);
				statement();
				}
				}
				setState(75); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__1) | (1L << T__3) | (1L << T__4) | (1L << T__9) | (1L << T__10) | (1L << T__11) | (1L << T__14) | (1L << T__15) | (1L << T__16) | (1L << T__19) | (1L << Identifier))) != 0) );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementContext extends ParserRuleContext {
		public DeklarasiContext deklarasi() {
			return getRuleContext(DeklarasiContext.class,0);
		}
		public PointerContext pointer() {
			return getRuleContext(PointerContext.class,0);
		}
		public ArrayContext array() {
			return getRuleContext(ArrayContext.class,0);
		}
		public StructContext struct() {
			return getRuleContext(StructContext.class,0);
		}
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitStatement(this);
		}
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_statement);
		try {
			setState(81);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(77);
				deklarasi();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(78);
				pointer();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(79);
				array();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(80);
				struct();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PointerContext extends ParserRuleContext {
		public List<Type_dataContext> type_data() {
			return getRuleContexts(Type_dataContext.class);
		}
		public Type_dataContext type_data(int i) {
			return getRuleContext(Type_dataContext.class,i);
		}
		public List<Init_pointer1Context> init_pointer1() {
			return getRuleContexts(Init_pointer1Context.class);
		}
		public Init_pointer1Context init_pointer1(int i) {
			return getRuleContext(Init_pointer1Context.class,i);
		}
		public List<Init_pointer2Context> init_pointer2() {
			return getRuleContexts(Init_pointer2Context.class);
		}
		public Init_pointer2Context init_pointer2(int i) {
			return getRuleContext(Init_pointer2Context.class,i);
		}
		public PointerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pointer; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterPointer(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitPointer(this);
		}
	}

	public final PointerContext pointer() throws RecognitionException {
		PointerContext _localctx = new PointerContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_pointer);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(95); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					setState(95);
					switch (_input.LA(1)) {
					case T__10:
					case T__14:
					case T__15:
					case T__16:
					case T__19:
						{
						{
						setState(83);
						type_data();
						setState(84);
						init_pointer1();
						setState(85);
						match(T__0);
						}
						}
						break;
					case Identifier:
						{
						{
						setState(87);
						init_pointer2();
						setState(88);
						match(T__0);
						}
						}
						break;
					case T__1:
						{
						{
						setState(90);
						match(T__1);
						setState(91);
						type_data();
						setState(92);
						init_pointer2();
						setState(93);
						match(T__0);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(97); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArrayContext extends ParserRuleContext {
		public Type_INTContext type_INT() {
			return getRuleContext(Type_INTContext.class,0);
		}
		public TerminalNode Identifier() { return getToken(inisialisasiParser.Identifier, 0); }
		public List<SizeContext> size() {
			return getRuleContexts(SizeContext.class);
		}
		public SizeContext size(int i) {
			return getRuleContext(SizeContext.class,i);
		}
		public Init_array1Context init_array1() {
			return getRuleContext(Init_array1Context.class,0);
		}
		public Init_array4Context init_array4() {
			return getRuleContext(Init_array4Context.class,0);
		}
		public Type_CHARContext type_CHAR() {
			return getRuleContext(Type_CHARContext.class,0);
		}
		public Init_array2Context init_array2() {
			return getRuleContext(Init_array2Context.class,0);
		}
		public Type_FLOATContext type_FLOAT() {
			return getRuleContext(Type_FLOATContext.class,0);
		}
		public Type_DOUBLEContext type_DOUBLE() {
			return getRuleContext(Type_DOUBLEContext.class,0);
		}
		public Init_array3Context init_array3() {
			return getRuleContext(Init_array3Context.class,0);
		}
		public ArrayContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_array; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterArray(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitArray(this);
		}
	}

	public final ArrayContext array() throws RecognitionException {
		ArrayContext _localctx = new ArrayContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_array);
		int _la;
		try {
			setState(154);
			switch (_input.LA(1)) {
			case T__10:
				enterOuterAlt(_localctx, 1);
				{
				{
				setState(99);
				type_INT();
				setState(100);
				match(Identifier);
				setState(102); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(101);
					size();
					}
					}
					setState(104); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==T__12 );
				setState(108);
				_la = _input.LA(1);
				if (_la==T__2) {
					{
					setState(106);
					match(T__2);
					setState(107);
					init_array1();
					}
				}

				setState(110);
				match(T__0);
				}
				}
				break;
			case T__3:
				enterOuterAlt(_localctx, 2);
				{
				{
				setState(112);
				match(T__3);
				setState(113);
				match(Identifier);
				setState(115); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(114);
					size();
					}
					}
					setState(117); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==T__12 );
				setState(121);
				_la = _input.LA(1);
				if (_la==T__2) {
					{
					setState(119);
					match(T__2);
					setState(120);
					init_array4();
					}
				}

				setState(123);
				match(T__0);
				}
				}
				break;
			case T__14:
				enterOuterAlt(_localctx, 3);
				{
				{
				setState(125);
				type_CHAR();
				setState(126);
				match(Identifier);
				setState(128); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(127);
					size();
					}
					}
					setState(130); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==T__12 );
				setState(134);
				_la = _input.LA(1);
				if (_la==T__2) {
					{
					setState(132);
					match(T__2);
					setState(133);
					init_array2();
					}
				}

				setState(136);
				match(T__0);
				}
				}
				break;
			case T__15:
			case T__16:
				enterOuterAlt(_localctx, 4);
				{
				{
				setState(140);
				switch (_input.LA(1)) {
				case T__15:
					{
					setState(138);
					type_FLOAT();
					}
					break;
				case T__16:
					{
					setState(139);
					type_DOUBLE();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(142);
				match(Identifier);
				setState(144); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(143);
					size();
					}
					}
					setState(146); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==T__12 );
				setState(150);
				_la = _input.LA(1);
				if (_la==T__2) {
					{
					setState(148);
					match(T__2);
					setState(149);
					init_array3();
					}
				}

				setState(152);
				match(T__0);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StructContext extends ParserRuleContext {
		public List<TerminalNode> Identifier() { return getTokens(inisialisasiParser.Identifier); }
		public TerminalNode Identifier(int i) {
			return getToken(inisialisasiParser.Identifier, i);
		}
		public List<DecContext> dec() {
			return getRuleContexts(DecContext.class);
		}
		public DecContext dec(int i) {
			return getRuleContext(DecContext.class,i);
		}
		public Init_structContext init_struct() {
			return getRuleContext(Init_structContext.class,0);
		}
		public StructContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_struct; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterStruct(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitStruct(this);
		}
	}

	public final StructContext struct() throws RecognitionException {
		StructContext _localctx = new StructContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_struct);
		int _la;
		try {
			int _alt;
			setState(192);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,18,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(166); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(156);
						match(T__4);
						setState(157);
						match(Identifier);
						setState(158);
						match(T__5);
						setState(160); 
						_errHandler.sync(this);
						_la = _input.LA(1);
						do {
							{
							{
							setState(159);
							dec();
							}
							}
							setState(162); 
							_errHandler.sync(this);
							_la = _input.LA(1);
						} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__3) | (1L << T__9) | (1L << T__10) | (1L << T__11) | (1L << T__14) | (1L << T__15) | (1L << T__16) | (1L << T__19))) != 0) );
						setState(164);
						match(T__6);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(168); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(181); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(170);
						match(T__4);
						setState(171);
						match(Identifier);
						setState(172);
						match(Identifier);
						setState(177);
						_errHandler.sync(this);
						_la = _input.LA(1);
						while (_la==T__7) {
							{
							{
							setState(173);
							match(T__7);
							setState(174);
							match(Identifier);
							}
							}
							setState(179);
							_errHandler.sync(this);
							_la = _input.LA(1);
						}
						setState(180);
						match(T__0);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(183); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				{
				setState(185);
				match(Identifier);
				setState(186);
				match(T__8);
				setState(187);
				match(Identifier);
				setState(188);
				match(T__2);
				setState(189);
				init_struct();
				setState(190);
				match(T__0);
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DecContext extends ParserRuleContext {
		public Type_dataContext type_data() {
			return getRuleContext(Type_dataContext.class,0);
		}
		public TerminalNode Identifier() { return getToken(inisialisasiParser.Identifier, 0); }
		public List<SizeContext> size() {
			return getRuleContexts(SizeContext.class);
		}
		public SizeContext size(int i) {
			return getRuleContext(SizeContext.class,i);
		}
		public Type_intContext type_int() {
			return getRuleContext(Type_intContext.class,0);
		}
		public DecContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dec; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterDec(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitDec(this);
		}
	}

	public final DecContext dec() throws RecognitionException {
		DecContext _localctx = new DecContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_dec);
		int _la;
		try {
			setState(214);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,21,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(194);
				type_data();
				setState(195);
				match(Identifier);
				setState(199);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__12) {
					{
					{
					setState(196);
					size();
					}
					}
					setState(201);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(202);
				match(T__0);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(204);
				type_int();
				setState(205);
				match(Identifier);
				setState(209);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__12) {
					{
					{
					setState(206);
					size();
					}
					}
					setState(211);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(212);
				match(T__0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Type_intContext extends ParserRuleContext {
		public Type_intContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_int; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterType_int(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitType_int(this);
		}
	}

	public final Type_intContext type_int() throws RecognitionException {
		Type_intContext _localctx = new Type_intContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_type_int);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(216);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__3) | (1L << T__9) | (1L << T__10) | (1L << T__11))) != 0)) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Init_structContext extends ParserRuleContext {
		public List<TerminalNode> INT() { return getTokens(inisialisasiParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(inisialisasiParser.INT, i);
		}
		public List<TerminalNode> CHAR() { return getTokens(inisialisasiParser.CHAR); }
		public TerminalNode CHAR(int i) {
			return getToken(inisialisasiParser.CHAR, i);
		}
		public List<TerminalNode> FLOAT() { return getTokens(inisialisasiParser.FLOAT); }
		public TerminalNode FLOAT(int i) {
			return getToken(inisialisasiParser.FLOAT, i);
		}
		public List<TerminalNode> DOUBLE() { return getTokens(inisialisasiParser.DOUBLE); }
		public TerminalNode DOUBLE(int i) {
			return getToken(inisialisasiParser.DOUBLE, i);
		}
		public Init_structContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_init_struct; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterInit_struct(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitInit_struct(this);
		}
	}

	public final Init_structContext init_struct() throws RecognitionException {
		Init_structContext _localctx = new Init_structContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_init_struct);
		int _la;
		try {
			setState(250);
			switch (_input.LA(1)) {
			case INT:
				enterOuterAlt(_localctx, 1);
				{
				setState(218);
				match(INT);
				setState(223);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__7) {
					{
					{
					setState(219);
					match(T__7);
					setState(220);
					match(INT);
					}
					}
					setState(225);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case CHAR:
				enterOuterAlt(_localctx, 2);
				{
				setState(226);
				match(CHAR);
				setState(231);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__7) {
					{
					{
					setState(227);
					match(T__7);
					setState(228);
					match(CHAR);
					}
					}
					setState(233);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case FLOAT:
				enterOuterAlt(_localctx, 3);
				{
				setState(234);
				match(FLOAT);
				setState(239);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__7) {
					{
					{
					setState(235);
					match(T__7);
					setState(236);
					match(FLOAT);
					}
					}
					setState(241);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case DOUBLE:
				enterOuterAlt(_localctx, 4);
				{
				setState(242);
				match(DOUBLE);
				setState(247);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__7) {
					{
					{
					setState(243);
					match(T__7);
					setState(244);
					match(DOUBLE);
					}
					}
					setState(249);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SizeContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(inisialisasiParser.INT, 0); }
		public SizeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_size; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterSize(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitSize(this);
		}
	}

	public final SizeContext size() throws RecognitionException {
		SizeContext _localctx = new SizeContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_size);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(252);
			match(T__12);
			setState(253);
			match(INT);
			setState(254);
			match(T__13);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Init_array1Context extends ParserRuleContext {
		public List<Value1Context> value1() {
			return getRuleContexts(Value1Context.class);
		}
		public Value1Context value1(int i) {
			return getRuleContext(Value1Context.class,i);
		}
		public Init_array1Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_init_array1; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterInit_array1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitInit_array1(this);
		}
	}

	public final Init_array1Context init_array1() throws RecognitionException {
		Init_array1Context _localctx = new Init_array1Context(_ctx, getState());
		enterRule(_localctx, 18, RULE_init_array1);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(256);
			match(T__5);
			setState(257);
			value1();
			setState(262);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__7) {
				{
				{
				setState(258);
				match(T__7);
				setState(259);
				value1();
				}
				}
				setState(264);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(265);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Init_array2Context extends ParserRuleContext {
		public List<Value2Context> value2() {
			return getRuleContexts(Value2Context.class);
		}
		public Value2Context value2(int i) {
			return getRuleContext(Value2Context.class,i);
		}
		public Init_array2Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_init_array2; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterInit_array2(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitInit_array2(this);
		}
	}

	public final Init_array2Context init_array2() throws RecognitionException {
		Init_array2Context _localctx = new Init_array2Context(_ctx, getState());
		enterRule(_localctx, 20, RULE_init_array2);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(267);
			match(T__5);
			setState(268);
			value2();
			setState(273);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__7) {
				{
				{
				setState(269);
				match(T__7);
				setState(270);
				value2();
				}
				}
				setState(275);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(276);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Init_array3Context extends ParserRuleContext {
		public List<Value3Context> value3() {
			return getRuleContexts(Value3Context.class);
		}
		public Value3Context value3(int i) {
			return getRuleContext(Value3Context.class,i);
		}
		public Init_array3Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_init_array3; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterInit_array3(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitInit_array3(this);
		}
	}

	public final Init_array3Context init_array3() throws RecognitionException {
		Init_array3Context _localctx = new Init_array3Context(_ctx, getState());
		enterRule(_localctx, 22, RULE_init_array3);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(278);
			match(T__5);
			setState(279);
			value3();
			setState(284);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__7) {
				{
				{
				setState(280);
				match(T__7);
				setState(281);
				value3();
				}
				}
				setState(286);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(287);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Init_array4Context extends ParserRuleContext {
		public List<Value4Context> value4() {
			return getRuleContexts(Value4Context.class);
		}
		public Value4Context value4(int i) {
			return getRuleContext(Value4Context.class,i);
		}
		public Init_array4Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_init_array4; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterInit_array4(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitInit_array4(this);
		}
	}

	public final Init_array4Context init_array4() throws RecognitionException {
		Init_array4Context _localctx = new Init_array4Context(_ctx, getState());
		enterRule(_localctx, 24, RULE_init_array4);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(289);
			match(T__5);
			setState(290);
			value4();
			setState(295);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__7) {
				{
				{
				setState(291);
				match(T__7);
				setState(292);
				value4();
				}
				}
				setState(297);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(298);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Value1Context extends ParserRuleContext {
		public Init_array1Context init_array1() {
			return getRuleContext(Init_array1Context.class,0);
		}
		public TerminalNode INT() { return getToken(inisialisasiParser.INT, 0); }
		public Value1Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_value1; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterValue1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitValue1(this);
		}
	}

	public final Value1Context value1() throws RecognitionException {
		Value1Context _localctx = new Value1Context(_ctx, getState());
		enterRule(_localctx, 26, RULE_value1);
		try {
			setState(302);
			switch (_input.LA(1)) {
			case T__5:
				enterOuterAlt(_localctx, 1);
				{
				setState(300);
				init_array1();
				}
				break;
			case INT:
				enterOuterAlt(_localctx, 2);
				{
				setState(301);
				match(INT);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Value2Context extends ParserRuleContext {
		public Init_array2Context init_array2() {
			return getRuleContext(Init_array2Context.class,0);
		}
		public TerminalNode CHAR() { return getToken(inisialisasiParser.CHAR, 0); }
		public Value2Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_value2; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterValue2(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitValue2(this);
		}
	}

	public final Value2Context value2() throws RecognitionException {
		Value2Context _localctx = new Value2Context(_ctx, getState());
		enterRule(_localctx, 28, RULE_value2);
		try {
			setState(306);
			switch (_input.LA(1)) {
			case T__5:
				enterOuterAlt(_localctx, 1);
				{
				setState(304);
				init_array2();
				}
				break;
			case CHAR:
				enterOuterAlt(_localctx, 2);
				{
				setState(305);
				match(CHAR);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Value3Context extends ParserRuleContext {
		public Init_array3Context init_array3() {
			return getRuleContext(Init_array3Context.class,0);
		}
		public TerminalNode FLOAT() { return getToken(inisialisasiParser.FLOAT, 0); }
		public TerminalNode DOUBLE() { return getToken(inisialisasiParser.DOUBLE, 0); }
		public Value3Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_value3; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterValue3(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitValue3(this);
		}
	}

	public final Value3Context value3() throws RecognitionException {
		Value3Context _localctx = new Value3Context(_ctx, getState());
		enterRule(_localctx, 30, RULE_value3);
		int _la;
		try {
			setState(310);
			switch (_input.LA(1)) {
			case T__5:
				enterOuterAlt(_localctx, 1);
				{
				setState(308);
				init_array3();
				}
				break;
			case FLOAT:
			case DOUBLE:
				enterOuterAlt(_localctx, 2);
				{
				setState(309);
				_la = _input.LA(1);
				if ( !(_la==FLOAT || _la==DOUBLE) ) {
				_errHandler.recoverInline(this);
				} else {
					consume();
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Value4Context extends ParserRuleContext {
		public Init_array4Context init_array4() {
			return getRuleContext(Init_array4Context.class,0);
		}
		public TerminalNode UNSG() { return getToken(inisialisasiParser.UNSG, 0); }
		public Value4Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_value4; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterValue4(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitValue4(this);
		}
	}

	public final Value4Context value4() throws RecognitionException {
		Value4Context _localctx = new Value4Context(_ctx, getState());
		enterRule(_localctx, 32, RULE_value4);
		try {
			setState(314);
			switch (_input.LA(1)) {
			case T__5:
				enterOuterAlt(_localctx, 1);
				{
				setState(312);
				init_array4();
				}
				break;
			case UNSG:
				enterOuterAlt(_localctx, 2);
				{
				setState(313);
				match(UNSG);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Type_CHARContext extends ParserRuleContext {
		public Type_CHARContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_CHAR; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterType_CHAR(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitType_CHAR(this);
		}
	}

	public final Type_CHARContext type_CHAR() throws RecognitionException {
		Type_CHARContext _localctx = new Type_CHARContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_type_CHAR);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(316);
			match(T__14);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Type_FLOATContext extends ParserRuleContext {
		public Type_FLOATContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_FLOAT; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterType_FLOAT(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitType_FLOAT(this);
		}
	}

	public final Type_FLOATContext type_FLOAT() throws RecognitionException {
		Type_FLOATContext _localctx = new Type_FLOATContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_type_FLOAT);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(318);
			match(T__15);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Type_DOUBLEContext extends ParserRuleContext {
		public Type_DOUBLEContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_DOUBLE; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterType_DOUBLE(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitType_DOUBLE(this);
		}
	}

	public final Type_DOUBLEContext type_DOUBLE() throws RecognitionException {
		Type_DOUBLEContext _localctx = new Type_DOUBLEContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_type_DOUBLE);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(320);
			match(T__16);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Type_INTContext extends ParserRuleContext {
		public Type_INTContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_INT; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterType_INT(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitType_INT(this);
		}
	}

	public final Type_INTContext type_INT() throws RecognitionException {
		Type_INTContext _localctx = new Type_INTContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_type_INT);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(322);
			match(T__10);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Init_pointer1Context extends ParserRuleContext {
		public List<TerminalNode> Identifier() { return getTokens(inisialisasiParser.Identifier); }
		public TerminalNode Identifier(int i) {
			return getToken(inisialisasiParser.Identifier, i);
		}
		public List<Init_pointer1Context> init_pointer1() {
			return getRuleContexts(Init_pointer1Context.class);
		}
		public Init_pointer1Context init_pointer1(int i) {
			return getRuleContext(Init_pointer1Context.class,i);
		}
		public Init_pointer1Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_init_pointer1; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterInit_pointer1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitInit_pointer1(this);
		}
	}

	public final Init_pointer1Context init_pointer1() throws RecognitionException {
		Init_pointer1Context _localctx = new Init_pointer1Context(_ctx, getState());
		enterRule(_localctx, 42, RULE_init_pointer1);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(324);
			match(T__17);
			setState(326);
			_la = _input.LA(1);
			if (_la==T__1) {
				{
				setState(325);
				match(T__1);
				}
			}

			setState(328);
			match(Identifier);
			setState(341);
			_la = _input.LA(1);
			if (_la==T__2) {
				{
				setState(329);
				match(T__2);
				setState(331);
				_la = _input.LA(1);
				if (_la==T__18) {
					{
					setState(330);
					match(T__18);
					}
				}

				setState(333);
				match(Identifier);
				setState(338);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,37,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(334);
						match(T__7);
						setState(335);
						init_pointer1();
						}
						} 
					}
					setState(340);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,37,_ctx);
				}
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Init_pointer2Context extends ParserRuleContext {
		public List<TerminalNode> Identifier() { return getTokens(inisialisasiParser.Identifier); }
		public TerminalNode Identifier(int i) {
			return getToken(inisialisasiParser.Identifier, i);
		}
		public List<Init_pointer2Context> init_pointer2() {
			return getRuleContexts(Init_pointer2Context.class);
		}
		public Init_pointer2Context init_pointer2(int i) {
			return getRuleContext(Init_pointer2Context.class,i);
		}
		public Init_pointer2Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_init_pointer2; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterInit_pointer2(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitInit_pointer2(this);
		}
	}

	public final Init_pointer2Context init_pointer2() throws RecognitionException {
		Init_pointer2Context _localctx = new Init_pointer2Context(_ctx, getState());
		enterRule(_localctx, 44, RULE_init_pointer2);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(343);
			match(Identifier);
			setState(356);
			_la = _input.LA(1);
			if (_la==T__2) {
				{
				setState(344);
				match(T__2);
				setState(346);
				_la = _input.LA(1);
				if (_la==T__18) {
					{
					setState(345);
					match(T__18);
					}
				}

				setState(348);
				match(Identifier);
				setState(353);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,40,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(349);
						match(T__7);
						setState(350);
						init_pointer2();
						}
						} 
					}
					setState(355);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,40,_ctx);
				}
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DeklarasiContext extends ParserRuleContext {
		public Type_dataContext type_data() {
			return getRuleContext(Type_dataContext.class,0);
		}
		public TypedataContext typedata() {
			return getRuleContext(TypedataContext.class,0);
		}
		public Integer_sContext integer_s() {
			return getRuleContext(Integer_sContext.class,0);
		}
		public DeklarasiContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_deklarasi; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterDeklarasi(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitDeklarasi(this);
		}
	}

	public final DeklarasiContext deklarasi() throws RecognitionException {
		DeklarasiContext _localctx = new DeklarasiContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_deklarasi);
		int _la;
		try {
			setState(374);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,45,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(359);
				_la = _input.LA(1);
				if (_la==T__3) {
					{
					setState(358);
					match(T__3);
					}
				}

				setState(362);
				_la = _input.LA(1);
				if (_la==T__9 || _la==T__11) {
					{
					setState(361);
					typedata();
					}
				}

				setState(364);
				type_data();
				setState(365);
				match(T__0);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(368);
				_la = _input.LA(1);
				if (_la==T__3) {
					{
					setState(367);
					match(T__3);
					}
				}

				setState(370);
				typedata();
				setState(371);
				integer_s();
				setState(372);
				match(T__0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypedataContext extends ParserRuleContext {
		public TypedataContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_typedata; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterTypedata(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitTypedata(this);
		}
	}

	public final TypedataContext typedata() throws RecognitionException {
		TypedataContext _localctx = new TypedataContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_typedata);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(376);
			_la = _input.LA(1);
			if ( !(_la==T__9 || _la==T__11) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Type_dataContext extends ParserRuleContext {
		public List<Integer_sContext> integer_s() {
			return getRuleContexts(Integer_sContext.class);
		}
		public Integer_sContext integer_s(int i) {
			return getRuleContext(Integer_sContext.class,i);
		}
		public List<Char_sContext> char_s() {
			return getRuleContexts(Char_sContext.class);
		}
		public Char_sContext char_s(int i) {
			return getRuleContext(Char_sContext.class,i);
		}
		public List<Float_sContext> float_s() {
			return getRuleContexts(Float_sContext.class);
		}
		public Float_sContext float_s(int i) {
			return getRuleContext(Float_sContext.class,i);
		}
		public List<Double_sContext> double_s() {
			return getRuleContexts(Double_sContext.class);
		}
		public Double_sContext double_s(int i) {
			return getRuleContext(Double_sContext.class,i);
		}
		public List<Boolean_sContext> boolean_s() {
			return getRuleContexts(Boolean_sContext.class);
		}
		public Boolean_sContext boolean_s(int i) {
			return getRuleContext(Boolean_sContext.class,i);
		}
		public Type_dataContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_data; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterType_data(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitType_data(this);
		}
	}

	public final Type_dataContext type_data() throws RecognitionException {
		Type_dataContext _localctx = new Type_dataContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_type_data);
		int _la;
		try {
			setState(431);
			switch (_input.LA(1)) {
			case T__10:
				enterOuterAlt(_localctx, 1);
				{
				setState(378);
				match(T__10);
				setState(387);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,47,_ctx) ) {
				case 1:
					{
					setState(379);
					integer_s();
					setState(384);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==T__7) {
						{
						{
						setState(380);
						match(T__7);
						setState(381);
						integer_s();
						}
						}
						setState(386);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
					break;
				}
				}
				break;
			case T__14:
				enterOuterAlt(_localctx, 2);
				{
				setState(389);
				match(T__14);
				setState(398);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,49,_ctx) ) {
				case 1:
					{
					setState(390);
					char_s();
					setState(395);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==T__7) {
						{
						{
						setState(391);
						match(T__7);
						setState(392);
						char_s();
						}
						}
						setState(397);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
					break;
				}
				}
				break;
			case T__15:
				enterOuterAlt(_localctx, 3);
				{
				setState(400);
				match(T__15);
				setState(409);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,51,_ctx) ) {
				case 1:
					{
					setState(401);
					float_s();
					setState(406);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==T__7) {
						{
						{
						setState(402);
						match(T__7);
						setState(403);
						float_s();
						}
						}
						setState(408);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
					break;
				}
				}
				break;
			case T__16:
				enterOuterAlt(_localctx, 4);
				{
				setState(411);
				match(T__16);
				setState(420);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,53,_ctx) ) {
				case 1:
					{
					setState(412);
					double_s();
					setState(417);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==T__7) {
						{
						{
						setState(413);
						match(T__7);
						setState(414);
						double_s();
						}
						}
						setState(419);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
					break;
				}
				}
				break;
			case T__19:
				enterOuterAlt(_localctx, 5);
				{
				setState(422);
				match(T__19);
				setState(423);
				boolean_s();
				setState(428);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__7) {
					{
					{
					setState(424);
					match(T__7);
					setState(425);
					boolean_s();
					}
					}
					setState(430);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Integer_sContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(inisialisasiParser.Identifier, 0); }
		public Integer_vContext integer_v() {
			return getRuleContext(Integer_vContext.class,0);
		}
		public Integer_sContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_integer_s; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterInteger_s(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitInteger_s(this);
		}
	}

	public final Integer_sContext integer_s() throws RecognitionException {
		Integer_sContext _localctx = new Integer_sContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_integer_s);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(433);
			match(Identifier);
			setState(435);
			_la = _input.LA(1);
			if (_la==T__2) {
				{
				setState(434);
				integer_v();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Integer_vContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(inisialisasiParser.INT, 0); }
		public Integer_vContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_integer_v; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterInteger_v(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitInteger_v(this);
		}
	}

	public final Integer_vContext integer_v() throws RecognitionException {
		Integer_vContext _localctx = new Integer_vContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_integer_v);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(437);
			match(T__2);
			setState(438);
			match(INT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Char_sContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(inisialisasiParser.Identifier, 0); }
		public Char_vContext char_v() {
			return getRuleContext(Char_vContext.class,0);
		}
		public Char_sContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_char_s; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterChar_s(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitChar_s(this);
		}
	}

	public final Char_sContext char_s() throws RecognitionException {
		Char_sContext _localctx = new Char_sContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_char_s);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(440);
			match(Identifier);
			setState(442);
			_la = _input.LA(1);
			if (_la==T__2) {
				{
				setState(441);
				char_v();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Char_vContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(inisialisasiParser.Identifier, 0); }
		public Char_vContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_char_v; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterChar_v(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitChar_v(this);
		}
	}

	public final Char_vContext char_v() throws RecognitionException {
		Char_vContext _localctx = new Char_vContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_char_v);
		try {
			setState(452);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,58,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(444);
				match(T__2);
				setState(445);
				match(T__20);
				setState(446);
				match(Identifier);
				setState(447);
				match(T__20);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(448);
				match(T__2);
				setState(449);
				match(T__21);
				setState(450);
				matchWildcard();
				setState(451);
				match(T__21);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Float_sContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(inisialisasiParser.Identifier, 0); }
		public Float_vContext float_v() {
			return getRuleContext(Float_vContext.class,0);
		}
		public Float_sContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_float_s; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterFloat_s(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitFloat_s(this);
		}
	}

	public final Float_sContext float_s() throws RecognitionException {
		Float_sContext _localctx = new Float_sContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_float_s);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(454);
			match(Identifier);
			setState(456);
			_la = _input.LA(1);
			if (_la==T__2) {
				{
				setState(455);
				float_v();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Float_vContext extends ParserRuleContext {
		public List<TerminalNode> INT() { return getTokens(inisialisasiParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(inisialisasiParser.INT, i);
		}
		public Float_vContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_float_v; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterFloat_v(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitFloat_v(this);
		}
	}

	public final Float_vContext float_v() throws RecognitionException {
		Float_vContext _localctx = new Float_vContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_float_v);
		try {
			setState(464);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,60,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(458);
				match(T__2);
				setState(459);
				match(INT);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(460);
				match(T__2);
				setState(461);
				match(INT);
				setState(462);
				match(T__8);
				setState(463);
				match(INT);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Double_sContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(inisialisasiParser.Identifier, 0); }
		public Double_vContext double_v() {
			return getRuleContext(Double_vContext.class,0);
		}
		public Double_sContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_double_s; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterDouble_s(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitDouble_s(this);
		}
	}

	public final Double_sContext double_s() throws RecognitionException {
		Double_sContext _localctx = new Double_sContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_double_s);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(466);
			match(Identifier);
			setState(468);
			_la = _input.LA(1);
			if (_la==T__2) {
				{
				setState(467);
				double_v();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Double_vContext extends ParserRuleContext {
		public List<TerminalNode> INT() { return getTokens(inisialisasiParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(inisialisasiParser.INT, i);
		}
		public Double_vContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_double_v; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterDouble_v(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitDouble_v(this);
		}
	}

	public final Double_vContext double_v() throws RecognitionException {
		Double_vContext _localctx = new Double_vContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_double_v);
		try {
			setState(476);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,62,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(470);
				match(T__2);
				setState(471);
				match(INT);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(472);
				match(T__2);
				setState(473);
				match(INT);
				setState(474);
				match(T__8);
				setState(475);
				match(INT);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Boolean_sContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(inisialisasiParser.Identifier, 0); }
		public Boolean_vContext boolean_v() {
			return getRuleContext(Boolean_vContext.class,0);
		}
		public Boolean_sContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolean_s; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterBoolean_s(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitBoolean_s(this);
		}
	}

	public final Boolean_sContext boolean_s() throws RecognitionException {
		Boolean_sContext _localctx = new Boolean_sContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_boolean_s);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(478);
			match(Identifier);
			setState(480);
			_la = _input.LA(1);
			if (_la==T__2) {
				{
				setState(479);
				boolean_v();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Boolean_vContext extends ParserRuleContext {
		public Boolean_vContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolean_v; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).enterBoolean_v(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof inisialisasiListener ) ((inisialisasiListener)listener).exitBoolean_v(this);
		}
	}

	public final Boolean_vContext boolean_v() throws RecognitionException {
		Boolean_vContext _localctx = new Boolean_vContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_boolean_v);
		try {
			setState(490);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,64,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(482);
				match(T__2);
				setState(483);
				match(T__22);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(484);
				match(T__2);
				setState(485);
				match(T__23);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(486);
				match(T__2);
				setState(487);
				match(T__24);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(488);
				match(T__2);
				setState(489);
				match(T__25);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3&\u01ef\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \4!"+
		"\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\3\2\6\2L\n\2\r\2\16\2M\3\3\3\3\3\3\3\3\5"+
		"\3T\n\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\6\4b\n\4\r\4\16"+
		"\4c\3\5\3\5\3\5\6\5i\n\5\r\5\16\5j\3\5\3\5\5\5o\n\5\3\5\3\5\3\5\3\5\3"+
		"\5\6\5v\n\5\r\5\16\5w\3\5\3\5\5\5|\n\5\3\5\3\5\3\5\3\5\3\5\6\5\u0083\n"+
		"\5\r\5\16\5\u0084\3\5\3\5\5\5\u0089\n\5\3\5\3\5\3\5\3\5\5\5\u008f\n\5"+
		"\3\5\3\5\6\5\u0093\n\5\r\5\16\5\u0094\3\5\3\5\5\5\u0099\n\5\3\5\3\5\5"+
		"\5\u009d\n\5\3\6\3\6\3\6\3\6\6\6\u00a3\n\6\r\6\16\6\u00a4\3\6\3\6\6\6"+
		"\u00a9\n\6\r\6\16\6\u00aa\3\6\3\6\3\6\3\6\3\6\7\6\u00b2\n\6\f\6\16\6\u00b5"+
		"\13\6\3\6\6\6\u00b8\n\6\r\6\16\6\u00b9\3\6\3\6\3\6\3\6\3\6\3\6\3\6\5\6"+
		"\u00c3\n\6\3\7\3\7\3\7\7\7\u00c8\n\7\f\7\16\7\u00cb\13\7\3\7\3\7\3\7\3"+
		"\7\3\7\7\7\u00d2\n\7\f\7\16\7\u00d5\13\7\3\7\3\7\5\7\u00d9\n\7\3\b\3\b"+
		"\3\t\3\t\3\t\7\t\u00e0\n\t\f\t\16\t\u00e3\13\t\3\t\3\t\3\t\7\t\u00e8\n"+
		"\t\f\t\16\t\u00eb\13\t\3\t\3\t\3\t\7\t\u00f0\n\t\f\t\16\t\u00f3\13\t\3"+
		"\t\3\t\3\t\7\t\u00f8\n\t\f\t\16\t\u00fb\13\t\5\t\u00fd\n\t\3\n\3\n\3\n"+
		"\3\n\3\13\3\13\3\13\3\13\7\13\u0107\n\13\f\13\16\13\u010a\13\13\3\13\3"+
		"\13\3\f\3\f\3\f\3\f\7\f\u0112\n\f\f\f\16\f\u0115\13\f\3\f\3\f\3\r\3\r"+
		"\3\r\3\r\7\r\u011d\n\r\f\r\16\r\u0120\13\r\3\r\3\r\3\16\3\16\3\16\3\16"+
		"\7\16\u0128\n\16\f\16\16\16\u012b\13\16\3\16\3\16\3\17\3\17\5\17\u0131"+
		"\n\17\3\20\3\20\5\20\u0135\n\20\3\21\3\21\5\21\u0139\n\21\3\22\3\22\5"+
		"\22\u013d\n\22\3\23\3\23\3\24\3\24\3\25\3\25\3\26\3\26\3\27\3\27\5\27"+
		"\u0149\n\27\3\27\3\27\3\27\5\27\u014e\n\27\3\27\3\27\3\27\7\27\u0153\n"+
		"\27\f\27\16\27\u0156\13\27\5\27\u0158\n\27\3\30\3\30\3\30\5\30\u015d\n"+
		"\30\3\30\3\30\3\30\7\30\u0162\n\30\f\30\16\30\u0165\13\30\5\30\u0167\n"+
		"\30\3\31\5\31\u016a\n\31\3\31\5\31\u016d\n\31\3\31\3\31\3\31\3\31\5\31"+
		"\u0173\n\31\3\31\3\31\3\31\3\31\5\31\u0179\n\31\3\32\3\32\3\33\3\33\3"+
		"\33\3\33\7\33\u0181\n\33\f\33\16\33\u0184\13\33\5\33\u0186\n\33\3\33\3"+
		"\33\3\33\3\33\7\33\u018c\n\33\f\33\16\33\u018f\13\33\5\33\u0191\n\33\3"+
		"\33\3\33\3\33\3\33\7\33\u0197\n\33\f\33\16\33\u019a\13\33\5\33\u019c\n"+
		"\33\3\33\3\33\3\33\3\33\7\33\u01a2\n\33\f\33\16\33\u01a5\13\33\5\33\u01a7"+
		"\n\33\3\33\3\33\3\33\3\33\7\33\u01ad\n\33\f\33\16\33\u01b0\13\33\5\33"+
		"\u01b2\n\33\3\34\3\34\5\34\u01b6\n\34\3\35\3\35\3\35\3\36\3\36\5\36\u01bd"+
		"\n\36\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37\5\37\u01c7\n\37\3 \3 \5"+
		" \u01cb\n \3!\3!\3!\3!\3!\3!\5!\u01d3\n!\3\"\3\"\5\"\u01d7\n\"\3#\3#\3"+
		"#\3#\3#\3#\5#\u01df\n#\3$\3$\5$\u01e3\n$\3%\3%\3%\3%\3%\3%\3%\3%\5%\u01ed"+
		"\n%\3%\2\2&\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62\64\66"+
		"8:<>@BDFH\2\5\4\2\6\6\f\16\3\2!\"\4\2\f\f\16\16\u0218\2K\3\2\2\2\4S\3"+
		"\2\2\2\6a\3\2\2\2\b\u009c\3\2\2\2\n\u00c2\3\2\2\2\f\u00d8\3\2\2\2\16\u00da"+
		"\3\2\2\2\20\u00fc\3\2\2\2\22\u00fe\3\2\2\2\24\u0102\3\2\2\2\26\u010d\3"+
		"\2\2\2\30\u0118\3\2\2\2\32\u0123\3\2\2\2\34\u0130\3\2\2\2\36\u0134\3\2"+
		"\2\2 \u0138\3\2\2\2\"\u013c\3\2\2\2$\u013e\3\2\2\2&\u0140\3\2\2\2(\u0142"+
		"\3\2\2\2*\u0144\3\2\2\2,\u0146\3\2\2\2.\u0159\3\2\2\2\60\u0178\3\2\2\2"+
		"\62\u017a\3\2\2\2\64\u01b1\3\2\2\2\66\u01b3\3\2\2\28\u01b7\3\2\2\2:\u01ba"+
		"\3\2\2\2<\u01c6\3\2\2\2>\u01c8\3\2\2\2@\u01d2\3\2\2\2B\u01d4\3\2\2\2D"+
		"\u01de\3\2\2\2F\u01e0\3\2\2\2H\u01ec\3\2\2\2JL\5\4\3\2KJ\3\2\2\2LM\3\2"+
		"\2\2MK\3\2\2\2MN\3\2\2\2N\3\3\2\2\2OT\5\60\31\2PT\5\6\4\2QT\5\b\5\2RT"+
		"\5\n\6\2SO\3\2\2\2SP\3\2\2\2SQ\3\2\2\2SR\3\2\2\2T\5\3\2\2\2UV\5\64\33"+
		"\2VW\5,\27\2WX\7\3\2\2Xb\3\2\2\2YZ\5.\30\2Z[\7\3\2\2[b\3\2\2\2\\]\7\4"+
		"\2\2]^\5\64\33\2^_\5.\30\2_`\7\3\2\2`b\3\2\2\2aU\3\2\2\2aY\3\2\2\2a\\"+
		"\3\2\2\2bc\3\2\2\2ca\3\2\2\2cd\3\2\2\2d\7\3\2\2\2ef\5*\26\2fh\7\35\2\2"+
		"gi\5\22\n\2hg\3\2\2\2ij\3\2\2\2jh\3\2\2\2jk\3\2\2\2kn\3\2\2\2lm\7\5\2"+
		"\2mo\5\24\13\2nl\3\2\2\2no\3\2\2\2op\3\2\2\2pq\7\3\2\2q\u009d\3\2\2\2"+
		"rs\7\6\2\2su\7\35\2\2tv\5\22\n\2ut\3\2\2\2vw\3\2\2\2wu\3\2\2\2wx\3\2\2"+
		"\2x{\3\2\2\2yz\7\5\2\2z|\5\32\16\2{y\3\2\2\2{|\3\2\2\2|}\3\2\2\2}~\7\3"+
		"\2\2~\u009d\3\2\2\2\177\u0080\5$\23\2\u0080\u0082\7\35\2\2\u0081\u0083"+
		"\5\22\n\2\u0082\u0081\3\2\2\2\u0083\u0084\3\2\2\2\u0084\u0082\3\2\2\2"+
		"\u0084\u0085\3\2\2\2\u0085\u0088\3\2\2\2\u0086\u0087\7\5\2\2\u0087\u0089"+
		"\5\26\f\2\u0088\u0086\3\2\2\2\u0088\u0089\3\2\2\2\u0089\u008a\3\2\2\2"+
		"\u008a\u008b\7\3\2\2\u008b\u009d\3\2\2\2\u008c\u008f\5&\24\2\u008d\u008f"+
		"\5(\25\2\u008e\u008c\3\2\2\2\u008e\u008d\3\2\2\2\u008f\u0090\3\2\2\2\u0090"+
		"\u0092\7\35\2\2\u0091\u0093\5\22\n\2\u0092\u0091\3\2\2\2\u0093\u0094\3"+
		"\2\2\2\u0094\u0092\3\2\2\2\u0094\u0095\3\2\2\2\u0095\u0098\3\2\2\2\u0096"+
		"\u0097\7\5\2\2\u0097\u0099\5\30\r\2\u0098\u0096\3\2\2\2\u0098\u0099\3"+
		"\2\2\2\u0099\u009a\3\2\2\2\u009a\u009b\7\3\2\2\u009b\u009d\3\2\2\2\u009c"+
		"e\3\2\2\2\u009cr\3\2\2\2\u009c\177\3\2\2\2\u009c\u008e\3\2\2\2\u009d\t"+
		"\3\2\2\2\u009e\u009f\7\7\2\2\u009f\u00a0\7\35\2\2\u00a0\u00a2\7\b\2\2"+
		"\u00a1\u00a3\5\f\7\2\u00a2\u00a1\3\2\2\2\u00a3\u00a4\3\2\2\2\u00a4\u00a2"+
		"\3\2\2\2\u00a4\u00a5\3\2\2\2\u00a5\u00a6\3\2\2\2\u00a6\u00a7\7\t\2\2\u00a7"+
		"\u00a9\3\2\2\2\u00a8\u009e\3\2\2\2\u00a9\u00aa\3\2\2\2\u00aa\u00a8\3\2"+
		"\2\2\u00aa\u00ab\3\2\2\2\u00ab\u00c3\3\2\2\2\u00ac\u00ad\7\7\2\2\u00ad"+
		"\u00ae\7\35\2\2\u00ae\u00b3\7\35\2\2\u00af\u00b0\7\n\2\2\u00b0\u00b2\7"+
		"\35\2\2\u00b1\u00af\3\2\2\2\u00b2\u00b5\3\2\2\2\u00b3\u00b1\3\2\2\2\u00b3"+
		"\u00b4\3\2\2\2\u00b4\u00b6\3\2\2\2\u00b5\u00b3\3\2\2\2\u00b6\u00b8\7\3"+
		"\2\2\u00b7\u00ac\3\2\2\2\u00b8\u00b9\3\2\2\2\u00b9\u00b7\3\2\2\2\u00b9"+
		"\u00ba\3\2\2\2\u00ba\u00c3\3\2\2\2\u00bb\u00bc\7\35\2\2\u00bc\u00bd\7"+
		"\13\2\2\u00bd\u00be\7\35\2\2\u00be\u00bf\7\5\2\2\u00bf\u00c0\5\20\t\2"+
		"\u00c0\u00c1\7\3\2\2\u00c1\u00c3\3\2\2\2\u00c2\u00a8\3\2\2\2\u00c2\u00b7"+
		"\3\2\2\2\u00c2\u00bb\3\2\2\2\u00c3\13\3\2\2\2\u00c4\u00c5\5\64\33\2\u00c5"+
		"\u00c9\7\35\2\2\u00c6\u00c8\5\22\n\2\u00c7\u00c6\3\2\2\2\u00c8\u00cb\3"+
		"\2\2\2\u00c9\u00c7\3\2\2\2\u00c9\u00ca\3\2\2\2\u00ca\u00cc\3\2\2\2\u00cb"+
		"\u00c9\3\2\2\2\u00cc\u00cd\7\3\2\2\u00cd\u00d9\3\2\2\2\u00ce\u00cf\5\16"+
		"\b\2\u00cf\u00d3\7\35\2\2\u00d0\u00d2\5\22\n\2\u00d1\u00d0\3\2\2\2\u00d2"+
		"\u00d5\3\2\2\2\u00d3\u00d1\3\2\2\2\u00d3\u00d4\3\2\2\2\u00d4\u00d6\3\2"+
		"\2\2\u00d5\u00d3\3\2\2\2\u00d6\u00d7\7\3\2\2\u00d7\u00d9\3\2\2\2\u00d8"+
		"\u00c4\3\2\2\2\u00d8\u00ce\3\2\2\2\u00d9\r\3\2\2\2\u00da\u00db\t\2\2\2"+
		"\u00db\17\3\2\2\2\u00dc\u00e1\7\36\2\2\u00dd\u00de\7\n\2\2\u00de\u00e0"+
		"\7\36\2\2\u00df\u00dd\3\2\2\2\u00e0\u00e3\3\2\2\2\u00e1\u00df\3\2\2\2"+
		"\u00e1\u00e2\3\2\2\2\u00e2\u00fd\3\2\2\2\u00e3\u00e1\3\2\2\2\u00e4\u00e9"+
		"\7\37\2\2\u00e5\u00e6\7\n\2\2\u00e6\u00e8\7\37\2\2\u00e7\u00e5\3\2\2\2"+
		"\u00e8\u00eb\3\2\2\2\u00e9\u00e7\3\2\2\2\u00e9\u00ea\3\2\2\2\u00ea\u00fd"+
		"\3\2\2\2\u00eb\u00e9\3\2\2\2\u00ec\u00f1\7!\2\2\u00ed\u00ee\7\n\2\2\u00ee"+
		"\u00f0\7!\2\2\u00ef\u00ed\3\2\2\2\u00f0\u00f3\3\2\2\2\u00f1\u00ef\3\2"+
		"\2\2\u00f1\u00f2\3\2\2\2\u00f2\u00fd\3\2\2\2\u00f3\u00f1\3\2\2\2\u00f4"+
		"\u00f9\7\"\2\2\u00f5\u00f6\7\n\2\2\u00f6\u00f8\7\"\2\2\u00f7\u00f5\3\2"+
		"\2\2\u00f8\u00fb\3\2\2\2\u00f9\u00f7\3\2\2\2\u00f9\u00fa\3\2\2\2\u00fa"+
		"\u00fd\3\2\2\2\u00fb\u00f9\3\2\2\2\u00fc\u00dc\3\2\2\2\u00fc\u00e4\3\2"+
		"\2\2\u00fc\u00ec\3\2\2\2\u00fc\u00f4\3\2\2\2\u00fd\21\3\2\2\2\u00fe\u00ff"+
		"\7\17\2\2\u00ff\u0100\7\36\2\2\u0100\u0101\7\20\2\2\u0101\23\3\2\2\2\u0102"+
		"\u0103\7\b\2\2\u0103\u0108\5\34\17\2\u0104\u0105\7\n\2\2\u0105\u0107\5"+
		"\34\17\2\u0106\u0104\3\2\2\2\u0107\u010a\3\2\2\2\u0108\u0106\3\2\2\2\u0108"+
		"\u0109\3\2\2\2\u0109\u010b\3\2\2\2\u010a\u0108\3\2\2\2\u010b\u010c\7\t"+
		"\2\2\u010c\25\3\2\2\2\u010d\u010e\7\b\2\2\u010e\u0113\5\36\20\2\u010f"+
		"\u0110\7\n\2\2\u0110\u0112\5\36\20\2\u0111\u010f\3\2\2\2\u0112\u0115\3"+
		"\2\2\2\u0113\u0111\3\2\2\2\u0113\u0114\3\2\2\2\u0114\u0116\3\2\2\2\u0115"+
		"\u0113\3\2\2\2\u0116\u0117\7\t\2\2\u0117\27\3\2\2\2\u0118\u0119\7\b\2"+
		"\2\u0119\u011e\5 \21\2\u011a\u011b\7\n\2\2\u011b\u011d\5 \21\2\u011c\u011a"+
		"\3\2\2\2\u011d\u0120\3\2\2\2\u011e\u011c\3\2\2\2\u011e\u011f\3\2\2\2\u011f"+
		"\u0121\3\2\2\2\u0120\u011e\3\2\2\2\u0121\u0122\7\t\2\2\u0122\31\3\2\2"+
		"\2\u0123\u0124\7\b\2\2\u0124\u0129\5\"\22\2\u0125\u0126\7\n\2\2\u0126"+
		"\u0128\5\"\22\2\u0127\u0125\3\2\2\2\u0128\u012b\3\2\2\2\u0129\u0127\3"+
		"\2\2\2\u0129\u012a\3\2\2\2\u012a\u012c\3\2\2\2\u012b\u0129\3\2\2\2\u012c"+
		"\u012d\7\t\2\2\u012d\33\3\2\2\2\u012e\u0131\5\24\13\2\u012f\u0131\7\36"+
		"\2\2\u0130\u012e\3\2\2\2\u0130\u012f\3\2\2\2\u0131\35\3\2\2\2\u0132\u0135"+
		"\5\26\f\2\u0133\u0135\7\37\2\2\u0134\u0132\3\2\2\2\u0134\u0133\3\2\2\2"+
		"\u0135\37\3\2\2\2\u0136\u0139\5\30\r\2\u0137\u0139\t\3\2\2\u0138\u0136"+
		"\3\2\2\2\u0138\u0137\3\2\2\2\u0139!\3\2\2\2\u013a\u013d\5\32\16\2\u013b"+
		"\u013d\7 \2\2\u013c\u013a\3\2\2\2\u013c\u013b\3\2\2\2\u013d#\3\2\2\2\u013e"+
		"\u013f\7\21\2\2\u013f%\3\2\2\2\u0140\u0141\7\22\2\2\u0141\'\3\2\2\2\u0142"+
		"\u0143\7\23\2\2\u0143)\3\2\2\2\u0144\u0145\7\r\2\2\u0145+\3\2\2\2\u0146"+
		"\u0148\7\24\2\2\u0147\u0149\7\4\2\2\u0148\u0147\3\2\2\2\u0148\u0149\3"+
		"\2\2\2\u0149\u014a\3\2\2\2\u014a\u0157\7\35\2\2\u014b\u014d\7\5\2\2\u014c"+
		"\u014e\7\25\2\2\u014d\u014c\3\2\2\2\u014d\u014e\3\2\2\2\u014e\u014f\3"+
		"\2\2\2\u014f\u0154\7\35\2\2\u0150\u0151\7\n\2\2\u0151\u0153\5,\27\2\u0152"+
		"\u0150\3\2\2\2\u0153\u0156\3\2\2\2\u0154\u0152\3\2\2\2\u0154\u0155\3\2"+
		"\2\2\u0155\u0158\3\2\2\2\u0156\u0154\3\2\2\2\u0157\u014b\3\2\2\2\u0157"+
		"\u0158\3\2\2\2\u0158-\3\2\2\2\u0159\u0166\7\35\2\2\u015a\u015c\7\5\2\2"+
		"\u015b\u015d\7\25\2\2\u015c\u015b\3\2\2\2\u015c\u015d\3\2\2\2\u015d\u015e"+
		"\3\2\2\2\u015e\u0163\7\35\2\2\u015f\u0160\7\n\2\2\u0160\u0162\5.\30\2"+
		"\u0161\u015f\3\2\2\2\u0162\u0165\3\2\2\2\u0163\u0161\3\2\2\2\u0163\u0164"+
		"\3\2\2\2\u0164\u0167\3\2\2\2\u0165\u0163\3\2\2\2\u0166\u015a\3\2\2\2\u0166"+
		"\u0167\3\2\2\2\u0167/\3\2\2\2\u0168\u016a\7\6\2\2\u0169\u0168\3\2\2\2"+
		"\u0169\u016a\3\2\2\2\u016a\u016c\3\2\2\2\u016b\u016d\5\62\32\2\u016c\u016b"+
		"\3\2\2\2\u016c\u016d\3\2\2\2\u016d\u016e\3\2\2\2\u016e\u016f\5\64\33\2"+
		"\u016f\u0170\7\3\2\2\u0170\u0179\3\2\2\2\u0171\u0173\7\6\2\2\u0172\u0171"+
		"\3\2\2\2\u0172\u0173\3\2\2\2\u0173\u0174\3\2\2\2\u0174\u0175\5\62\32\2"+
		"\u0175\u0176\5\66\34\2\u0176\u0177\7\3\2\2\u0177\u0179\3\2\2\2\u0178\u0169"+
		"\3\2\2\2\u0178\u0172\3\2\2\2\u0179\61\3\2\2\2\u017a\u017b\t\4\2\2\u017b"+
		"\63\3\2\2\2\u017c\u0185\7\r\2\2\u017d\u0182\5\66\34\2\u017e\u017f\7\n"+
		"\2\2\u017f\u0181\5\66\34\2\u0180\u017e\3\2\2\2\u0181\u0184\3\2\2\2\u0182"+
		"\u0180\3\2\2\2\u0182\u0183\3\2\2\2\u0183\u0186\3\2\2\2\u0184\u0182\3\2"+
		"\2\2\u0185\u017d\3\2\2\2\u0185\u0186\3\2\2\2\u0186\u01b2\3\2\2\2\u0187"+
		"\u0190\7\21\2\2\u0188\u018d\5:\36\2\u0189\u018a\7\n\2\2\u018a\u018c\5"+
		":\36\2\u018b\u0189\3\2\2\2\u018c\u018f\3\2\2\2\u018d\u018b\3\2\2\2\u018d"+
		"\u018e\3\2\2\2\u018e\u0191\3\2\2\2\u018f\u018d\3\2\2\2\u0190\u0188\3\2"+
		"\2\2\u0190\u0191\3\2\2\2\u0191\u01b2\3\2\2\2\u0192\u019b\7\22\2\2\u0193"+
		"\u0198\5> \2\u0194\u0195\7\n\2\2\u0195\u0197\5> \2\u0196\u0194\3\2\2\2"+
		"\u0197\u019a\3\2\2\2\u0198\u0196\3\2\2\2\u0198\u0199\3\2\2\2\u0199\u019c"+
		"\3\2\2\2\u019a\u0198\3\2\2\2\u019b\u0193\3\2\2\2\u019b\u019c\3\2\2\2\u019c"+
		"\u01b2\3\2\2\2\u019d\u01a6\7\23\2\2\u019e\u01a3\5B\"\2\u019f\u01a0\7\n"+
		"\2\2\u01a0\u01a2\5B\"\2\u01a1\u019f\3\2\2\2\u01a2\u01a5\3\2\2\2\u01a3"+
		"\u01a1\3\2\2\2\u01a3\u01a4\3\2\2\2\u01a4\u01a7\3\2\2\2\u01a5\u01a3\3\2"+
		"\2\2\u01a6\u019e\3\2\2\2\u01a6\u01a7\3\2\2\2\u01a7\u01b2\3\2\2\2\u01a8"+
		"\u01a9\7\26\2\2\u01a9\u01ae\5F$\2\u01aa\u01ab\7\n\2\2\u01ab\u01ad\5F$"+
		"\2\u01ac\u01aa\3\2\2\2\u01ad\u01b0\3\2\2\2\u01ae\u01ac\3\2\2\2\u01ae\u01af"+
		"\3\2\2\2\u01af\u01b2\3\2\2\2\u01b0\u01ae\3\2\2\2\u01b1\u017c\3\2\2\2\u01b1"+
		"\u0187\3\2\2\2\u01b1\u0192\3\2\2\2\u01b1\u019d\3\2\2\2\u01b1\u01a8\3\2"+
		"\2\2\u01b2\65\3\2\2\2\u01b3\u01b5\7\35\2\2\u01b4\u01b6\58\35\2\u01b5\u01b4"+
		"\3\2\2\2\u01b5\u01b6\3\2\2\2\u01b6\67\3\2\2\2\u01b7\u01b8\7\5\2\2\u01b8"+
		"\u01b9\7\36\2\2\u01b99\3\2\2\2\u01ba\u01bc\7\35\2\2\u01bb\u01bd\5<\37"+
		"\2\u01bc\u01bb\3\2\2\2\u01bc\u01bd\3\2\2\2\u01bd;\3\2\2\2\u01be\u01bf"+
		"\7\5\2\2\u01bf\u01c0\7\27\2\2\u01c0\u01c1\7\35\2\2\u01c1\u01c7\7\27\2"+
		"\2\u01c2\u01c3\7\5\2\2\u01c3\u01c4\7\30\2\2\u01c4\u01c5\13\2\2\2\u01c5"+
		"\u01c7\7\30\2\2\u01c6\u01be\3\2\2\2\u01c6\u01c2\3\2\2\2\u01c7=\3\2\2\2"+
		"\u01c8\u01ca\7\35\2\2\u01c9\u01cb\5@!\2\u01ca\u01c9\3\2\2\2\u01ca\u01cb"+
		"\3\2\2\2\u01cb?\3\2\2\2\u01cc\u01cd\7\5\2\2\u01cd\u01d3\7\36\2\2\u01ce"+
		"\u01cf\7\5\2\2\u01cf\u01d0\7\36\2\2\u01d0\u01d1\7\13\2\2\u01d1\u01d3\7"+
		"\36\2\2\u01d2\u01cc\3\2\2\2\u01d2\u01ce\3\2\2\2\u01d3A\3\2\2\2\u01d4\u01d6"+
		"\7\35\2\2\u01d5\u01d7\5D#\2\u01d6\u01d5\3\2\2\2\u01d6\u01d7\3\2\2\2\u01d7"+
		"C\3\2\2\2\u01d8\u01d9\7\5\2\2\u01d9\u01df\7\36\2\2\u01da\u01db\7\5\2\2"+
		"\u01db\u01dc\7\36\2\2\u01dc\u01dd\7\13\2\2\u01dd\u01df\7\36\2\2\u01de"+
		"\u01d8\3\2\2\2\u01de\u01da\3\2\2\2\u01dfE\3\2\2\2\u01e0\u01e2\7\35\2\2"+
		"\u01e1\u01e3\5H%\2\u01e2\u01e1\3\2\2\2\u01e2\u01e3\3\2\2\2\u01e3G\3\2"+
		"\2\2\u01e4\u01e5\7\5\2\2\u01e5\u01ed\7\31\2\2\u01e6\u01e7\7\5\2\2\u01e7"+
		"\u01ed\7\32\2\2\u01e8\u01e9\7\5\2\2\u01e9\u01ed\7\33\2\2\u01ea\u01eb\7"+
		"\5\2\2\u01eb\u01ed\7\34\2\2\u01ec\u01e4\3\2\2\2\u01ec\u01e6\3\2\2\2\u01ec"+
		"\u01e8\3\2\2\2\u01ec\u01ea\3\2\2\2\u01edI\3\2\2\2CMSacjnw{\u0084\u0088"+
		"\u008e\u0094\u0098\u009c\u00a4\u00aa\u00b3\u00b9\u00c2\u00c9\u00d3\u00d8"+
		"\u00e1\u00e9\u00f1\u00f9\u00fc\u0108\u0113\u011e\u0129\u0130\u0134\u0138"+
		"\u013c\u0148\u014d\u0154\u0157\u015c\u0163\u0166\u0169\u016c\u0172\u0178"+
		"\u0182\u0185\u018d\u0190\u0198\u019b\u01a3\u01a6\u01ae\u01b1\u01b5\u01bc"+
		"\u01c6\u01ca\u01d2\u01d6\u01de\u01e2\u01ec";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}